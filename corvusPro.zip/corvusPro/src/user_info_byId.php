<?php  echo file_get_contents("head.html"); ?>
<?php echo file_get_contents("header.php");?>
<?php
session_start();

                          
                            
                            $ev = $_GET["id"];
                            $conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");
                            // Check connection
                            if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                            }
                            $sql = "SELECT a.name role, photo image, concat(u.name,' ',u.last_name) name, u.email email,u.birthdate date from users u 
                            left join accounts a on u.id_account = a.id
                            where u.username = '$ev'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                $name = $row['name'];
                                $role = $row['role'];
                                $date = $row['date'];
                                $email = $row['email'];
                                $img = $row['image'];
                                }
                            }

                            echo "<div class=\"page-title parallax parallax1\">";
                            echo "<div class=\"container\">";
                            echo "<div class=\"row\">";
                            echo "<div class=\"col-md-12\">  ";                  
                            echo "<div class=\"page-title-heading\">";
                            echo "<img src=\"https://i.pinimg.com/originals/56/3a/db/563adbeb015fb165c4145a28a6c2e4c8.jpg\">";
                            echo "</div><!-- /.page-title-captions --> ";
                            echo " </div><!-- /.col-md-12 -->  ";
                            echo "</div><!-- /.row -->  ";
                            echo "</div><!-- /.container -->";                      
                            echo "</div><!-- /.page-title --> ";

                            echo "<section class=\"flat-row\">";
                            echo "<div class=\"container\">";
                            echo "<div class=\"row\">";
                            echo "<div class=\"col-md-4\">";
                            echo "<ul class=\"entry-portfolio-details\">";
                            echo "<li><span>User     </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$name."</li> ";
                            echo "<li><span>username   </span>&nbsp;&nbsp;&nbsp;".$ev."</li>";
                            echo "<li><span>Role    </span>&nbsp;&nbsp;&nbsp;&nbsp;".$role."</li> ";
                            echo "<li><span>Date      </span>&nbsp;&nbsp;&nbsp;&nbsp;".$date."</li>";    
                            echo "<li><span>email  </span>&nbsp;&nbsp;".$email."</li>";
                            $sql = "SELECT t.name from userxtypes ut
                            join user_types t on ut.type_id=t.id 
                            where ut.username = $ev";
                            $result = $conn->query($sql);
                            echo "<li><span>Groups</span>";
                            if(!$result){
                                echo "no groups";
                            } else{
                                while($row = $result->fetch_assoc()) {
                                    echo $row['name'];
                                }
                            }
                            echo "</li>";
                               
                           /*<!--- <li class="share"><span>share&nbsp;&nbsp;</span>
                                <ul class="flat-socials">
                                    <li class="facebook">
                                        <a href="#"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li class="twitter">
                                        <a href="#"><i class="fa fa-twitter"></i></a>
                                    </li>                                
                                    <li class="linkedin">
                                        <a href="#"><i class="fa fa-linkedin"></i></a>
                                    </li>
                                    <li class="instagram">
                                        <a href="#"><i class="fa fa-instagram"></i></a>
                                    </li>
                                </ul>
                            </li>  --> */                        
                        echo"</ul>";
                    echo"</div><!-- /.col-md-4 -->";

                    echo"<div class=\"col-md-8\">";
                        echo"<div class=\"content-portfolio-detail\">";
                        
                        $sql = "SELECT photo from users where username = '$ev'";
                        $result = $conn->query($sql);
                        
                        if($result){
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo    "<img src=\"".$row["photo"]."\" height=\"100\" width=\"300\">";
                                }
                            }
                        } else{
                            echo "<p>No image".$ev."</p>";
                        }
                        echo    "</div>";
                        echo    "</div><!-- /.col-md-8 -->";
                echo "</div><!-- /.row -->";
                echo "<div class=\"flat-divider d51px\"></div>";
            
            echo "</section>";
            echo "<section class=\"flat-row\">";
            
            echo "<div class=\"container\">";
            echo "<div class=\"row\">";
            echo "<div class=\"update\">";
            echo "<h1>Update info</h1>";
            echo "<form action=\"dataAccess/updUser.php\" method=\"post\">";
            echo "<label>name</label>";
            echo "<input type=\"text\" name=\"name\" placeholder=\"".$name."\" value=\"".$name."\" id=\"name\" required>";
            echo "<br></br>";
            echo "<label>role</label>";
            echo "<input type=\"text\" name=\"role\" placeholder=\"".$role."\" value=\"".$role."\" id=\"role\">";
            echo "<br></br>";
            echo "<label>img</label>";
            echo "<input type=\"url\" name=\"image\" placeholder=\"".$img."\" value=\"".$img."\" id=\"image\" required>";
            echo "<label>email</label>";
            echo "<input type=\"text\" name=\"email\" placeholder=\"".$email."\" value=\"".$email."\" id=\"email\" required>";
            echo "<label>date</label>";
            echo "<input type=\"date\" name=\"date\" placeholder=\"".$date."\" value=\"".$date."\" id=\"date\" required>";
            echo "<input type=\"submit\" value=\"Login\">";
            echo "</form>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
            echo "</section>";
        ?>
<?php echo file_get_contents("content.html"); ?>

<?php echo file_get_contents("footer.html"); ?>