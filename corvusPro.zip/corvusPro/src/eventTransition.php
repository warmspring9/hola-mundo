<?php
$id = $_GET["id"];

$_SESSION["event"] = $id;
echo $id;
//header('Location: work_detail.php');

}
?>