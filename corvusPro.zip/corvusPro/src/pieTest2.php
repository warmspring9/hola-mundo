<?php  echo file_get_contents("head.html"); ?>
<?php 

$dataPoints = array();
$conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT user_types.name name, count(type_id) li , (select count(1) from users)  as tot
    FROM usersxtypes left join  user_types on usersxtypes.type_id=user_types.id
    group by type_id;";
    $result = $conn->query($sql);
    if ($result) {
        while($row = $result->fetch_assoc()) {
            array_push($dataPoints,array("label"=>$row["name"],"y"=>$row["li"]/$row["tot"]));
        }
    }
echo file_get_contents("adminHeader.php");

echo"<section class=\"flat-row pad-bottom90px\">";
echo"<div class=\"container\">";
echo"<div class=\"row\">";
echo"<div class=\"col-md-12\">";
echo"<div class=\"title-section\">";
 

 
?>
<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Usuarios"
	},
	subtitles: [{
		text: "per grupos"
	}],
	data: [{
		type: "pie",
		yValueFormatString: "#,##0.00\"%\"",
		indexLabel: "{label} ({y})",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
}
</script>

</div>
</div>

</div>

</div>

</section>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<div class="login">
<a href="pieTest.php"><button>prev</button></a>
<a href="pieTest3.php"><button>next</button></a>
</div>
<?php echo file_get_contents("footer.html"); ?>