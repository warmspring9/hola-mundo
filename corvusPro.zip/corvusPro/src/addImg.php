<?php  echo file_get_contents("head.html"); ?>
<?php echo file_get_contents("header.php");?>
<div class="update">
<?php
    include "dataAccess/DBcon.php";
    $con = con();
    $id = $_GET["id"];
    $sql = "SELECT name from events where id = $id";
    $result = $con->query($sql);
    if ($result) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
        echo "<h1>Add Image to Event ".$row["name"]."</h1>";
        echo "<form method=\"post\" action=\"dataAccess/includeImg.php\" required>";
        echo "<input type=\"text\" name=\"id\" value=\"".$id."\" hidden>";
        echo "<label for=\"image\">url</label>";
        echo "<input type=\"url\" name=\"image\" placeholder=\"image\" required>";
        }
    }

echo "<input type=\"submit\" value=\"Submit\">";
echo "<a href='addCategory.php?id=".$id."'><input type=\"button\" value=\"Next\" ></a>";
?>
</form>
</div>
<?php echo file_get_contents("footer.html");?>