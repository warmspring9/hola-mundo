<?php  echo file_get_contents("head.html"); ?>
<?php echo file_get_contents("header.php");?>

<div class="update">
<h1>Event creation</h1>
<form method="post" action="dataAccess/createEv.php" required>
<input type="text" name="name" placeholder="name" required>
<input id="textArea" type="text" name="description" placeholder="description" required>
<input type="text" name="location" placeholder="location" required>
<input type="checkbox" name="public" placeholder="public" >
<label>public</label>
<input type="date" name="date" placeholder="date" required>
<input type="submit" value="Submit">
</form>
</div>

<?php echo file_get_contents("footer.html");?>