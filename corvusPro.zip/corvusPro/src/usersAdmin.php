<?php  echo file_get_contents("head.html"); ?>
<?php 
echo file_get_contents("adminHeader.php");?>
<?php 
echo"<section class=\"flat-row pad-bottom90px\">";
echo"<div class=\"container\">";
echo"<div class=\"row\">";
echo"<div class=\"col-md-12\">";
echo"<div class=\"title-section\">";
echo "<div class=\"login\"><h1>Asociate group</h1><form method=\"post\" action=\"dataAccess/assGroup.php\">
<input type=\"text\" name=\"name\" placeholder=\"username\" required>
<input type=\"text\" name=\"group\" placeholder=\"group_id\" required>
<input type=\"submit\" value=\"Associate\">
</form></div>";
echo "
<table border=\"1\" style=\"width:100%\">
<thead>
  <tr>
  <th>Name</th>
  <th>Email</th>
  <th>Username</th>
  <th>Group</th>
  <th>birthdate</th>
  <th>edit</th>
   </tr>
</thead>";
$conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT u.name name, u.email email, u.username id, t.name grp, birthdate brtd FROM users u left join usersxtypes ut on u.username=ut.username left join user_types t on ut.type_id=t.id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo    "<tr>";
            echo    "<td>".$row["name"]."</td>";
            echo    "<td>".$row["email"]."</td>";
            echo    "<td>".$row["id"]."</td>";
            echo    "<td>".$row["grp"]."</td>";
            echo    "<td>".$row["brtd"]."</td>";
            echo    "<td><a class=\"btn btn-success\" href=\"user_info_byId.php?id=".$row["id"]."\">EDIT</a></td>";
            echo    "</tr>";
        }
    }
    echo "</table>";
    echo"</div><!-- /.title-section -->";
    echo"</div><!-- /.col-md-12 -->";
    echo"</div><!-- /.row -->";
    echo"</div>";

echo"<div class=\"flat-divider d51px\"></div>";

    ?>
<br></br>
</section>

<?php echo file_get_contents("footer.html"); ?>