<?php  echo file_get_contents("head.html"); ?>
<?php 
echo "<table border=\"1\" style=\"width:100%\">";
echo "<thead>";
echo "<tr>";
echo "<th>event</th>";


    include "dataAccess/DBcon.php";
    $con = con();
echo "<th>avg</th>";
echo "</tr>";
echo "</thead>";
$conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT assited.name, count(assited.id_event) as cant FROM (select events.name ,replies.id_event from replies left join events on replies.id_event = events.id where replies.type = 'No_Asistire' ) as assited group by name order by count(assited.id_event) limit 5";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo    "<tr>";
            echo    "<td>".$row["name"]."</td>";
            echo    "<td>".$row["avarage"]."</td>";
            echo    "</tr>";
        }
    }
    echo "</table>";
    echo "</div>";
?>
<div class="login">
<a href="pieTest7.php"><button>prev</button></a>
<a href="topN2.php"><button>next</button></a>
</div>
<?php echo file_get_contents("footer.html"); ?>