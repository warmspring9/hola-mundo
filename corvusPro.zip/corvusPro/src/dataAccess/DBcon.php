<?php
function con(){
	return new mysqli("localhost","WPPro2","Password9","prodb");
}
?>