<?php
include "DBcon.php";
session_start();
$us = $_SESSION["username"];
$id = filter_input(INPUT_POST, 'id');
$coment = filter_input(INPUT_POST, 'comment');
$con = con();
$con->query("INSERT INTO `comments`(`id_user`, `id_event`, content) VALUES ('$us',$id,'$coment')");
    header('location: ../work_detail.php?id='.$id);
?>