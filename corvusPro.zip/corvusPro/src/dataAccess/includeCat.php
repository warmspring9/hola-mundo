<?php
include "DBcon.php";
session_start();
$id = filter_input(INPUT_POST, 'id');
$img = filter_input(INPUT_POST, 'category');
echo $img;
$con = con();
if($con->query("insert into categoryxevent (id_event, id_category) 
    values ($id,'$img')")){
        echo "success";
}else {
    echo "error";
}
header("location: ../addCategory.php?id=".$id."");
?>