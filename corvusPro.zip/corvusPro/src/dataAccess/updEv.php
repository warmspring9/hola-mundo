<?php
include "DBcon.php";
session_start();
$description = filter_input(INPUT_POST, 'description');
$name = filter_input(INPUT_POST, 'name');
$location = filter_input(INPUT_POST, 'location');
$public = filter_input(INPUT_POST, 'public');
$date = filter_input(INPUT_POST, 'date');
$id = filter_input(INPUT_POST, 'id');

if($public){
    $privacy = 'public';
} else{
    $privacy = 'private';
}

    $con = con();
    $con->query("update events set name='$name', location = '$location', privacy='$privacy',description='$description', date='$date' where id=$id ");

    
    header('location: ../addImg.php?id='.$id);
?>