<?php
include "DBcon.php";
session_start();
$id = filter_input(INPUT_POST, 'id');
$img = filter_input(INPUT_POST, 'image');
echo $img;
$con = con();
if($con->query("insert into event_photos (id_event, url) 
    values (".$id.",'".$img."')")){
        echo "success";
}else {
    echo "error";
}
header("location: ../addImg.php?id=".$id."");
?>