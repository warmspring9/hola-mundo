<?php
include "DBcon.php";
$username = filter_input(INPUT_POST, 'username');
$name = filter_input(INPUT_POST, 'name');
$lastname = filter_input(INPUT_POST, 'lastname');
$password = filter_input(INPUT_POST, 'password');
$date = filter_input(INPUT_POST, 'birthdate');
$email = filter_input(INPUT_POST, 'email');

$ciphering = "AES-128-CTR"; 
  
// Use OpenSSl Encryption method 
$iv_length = openssl_cipher_iv_length($ciphering); 
$options = 0; 
  
// Non-NULL Initialization Vector for encryption 
$encryption_iv = '1234567891011121'; 
  
// Store the encryption key 
$encryption_key = "encryptionMan"; 
  
// Use openssl_encrypt() function to encrypt the data 
$encryption = openssl_encrypt($password, $ciphering, 
            $encryption_key, $options, $encryption_iv); 

    $con = con();
    $con->query("insert into users (username, name, last_name, password, email, birthdate) 
    values (\"$username\",\"$name\",\"$lastname\",\"$encryption\",\"$email\",'$date')");
    header('location: ../logIn.php');


?>