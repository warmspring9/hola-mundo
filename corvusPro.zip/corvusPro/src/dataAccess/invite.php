<?php
include "DBcon.php";
$id = filter_input(INPUT_POST, 'id');
$correo = filter_input(INPUT_POST, 'email');

$conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");
$con = con();
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT username user FROM users where email='$correo'";
$result = $conn->query($sql);
if ($result) {
    while($row = $result->fetch_assoc()) {
        $us = $row["user"];
        echo $us;
        $con->query("INSERT INTO invites(`id_user`, `id_event`) VALUES ('$us',$id)");
    }
} else{
    echo "fail";
}
echo $correo;
echo $id;

//header('location: ../invEvent.php?id='.$id);
?>