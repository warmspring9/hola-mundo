<?php
include "DBcon.php";
session_start();
$username = $_SESSION["username"];
$name = explode(" ",filter_input(INPUT_POST, 'name'));
$lastname = filter_input(INPUT_POST, 'lastname');
$date = filter_input(INPUT_POST, 'date');
$email = filter_input(INPUT_POST, 'email');
$image = filter_input(INPUT_POST, 'image');

echo $date;
    $con = con();
    if($con->query("update users set
    name = '$name[0]',
    last_name = '$name[1]',
    email = '$email',
    photo = '$image',
    birthdate = '$date'
    where username='$username'")){
        echo "update succes";
    } else{
        echo "error";
    }
    header('location: ../user_info.php');


?>