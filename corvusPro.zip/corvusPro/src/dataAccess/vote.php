<?php
include "DBcon.php";
session_start();
$us = $_SESSION["username"];
$id = $_GET["id"];
$vote = $_GET["vote"];

$con = con();
if($con->query("insert into replies (id_event, type, id_user) 
    values ($id,'$vote','$us')")){
        echo "success";
}else {
    echo "error";
}
header("location: ../work_detail.php?id=".$id."");
?>