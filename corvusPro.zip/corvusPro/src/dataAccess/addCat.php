<?php
include "DBcon.php";
$name = filter_input(INPUT_POST, 'name');
$con = con();
$con->query("INSERT INTO `category`(`name`, `status`) VALUES ('$name','act')");
    header('location: ../catCRUD.php');
?>