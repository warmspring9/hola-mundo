<?php
include "DBcon.php";
$ev = $_GET["id"];
echo $ev;
$con = con();
if($con->query("update events set status='dis' where id=$ev ")){
    echo "success";
}
header('location: ../myEvents.php');

?>