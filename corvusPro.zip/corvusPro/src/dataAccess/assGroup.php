<?php
include "DBcon.php";
$name = filter_input(INPUT_POST, 'name');
$group = filter_input(INPUT_POST, 'group');
$con = con();
$con->query("INSERT INTO `usersxtypes`(username,type_id) VALUES ('$name',$group)");
    header('location: ../usersAdmin.php');
?>