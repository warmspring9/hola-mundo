<?php 
include "DBcon.php";

session_start();

$con = con();
if ( mysqli_connect_errno() ) {
	// If there is an error with the connection, stop the script and display the error.
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());
}
// Now we check if the data from the login form was submitted, isset() will check if the data exists.
if ( !isset($_POST['username'], $_POST['password']) ) {
	// Could not get the data that should have been sent.
	die ('Please fill both the username and password field!');
}
// Prepare our SQL, preparing the SQL statement will prevent SQL injection.
if ($stmt = $con->prepare('SELECT name, password, id_account FROM users WHERE username = ?')) {
	// Bind parameters (s = string, i = int, b = blob, etc), in our case the username is a string so we use "s"
	$stmt->bind_param('s', $_POST['username']);
	$stmt->execute();
	// Store the result so we can check if the account exists in the database.
	$stmt->store_result();
}
if ($stmt->num_rows > 0) {
	$stmt->bind_result($name, $password, $account);
	$stmt->fetch();
	// Account exists, now we verify the password.
	// Note: remember to use password_hash in your registration file to store the hashed passwords.
	//if (password_verify($_POST['password'], $password)) { unimplemented
	$decryption_iv = '1234567891011121';   
	$ciphering = "AES-128-CTR"; 
  
// Use OpenSSl Encryption method 
	$iv_length = openssl_cipher_iv_length($ciphering); 
	$options = 0; 
// Store the decryption key 
	$decryption_key = "encryptionMan"; 
  
// Use openssl_decrypt() function to decrypt the data 
	$decryption=openssl_decrypt ($password, $ciphering,  
		$decryption_key, $options, $decryption_iv);
	echo $password;
	echo $decryption;
    if ($_POST['password'] === $decryption) {
		// Verification success! User has loggedin!
		// Create sessions so we know the user is logged in, they basically act like cookies but remember the data on the server.
		session_regenerate_id();
		$_SESSION['loggedin'] = TRUE;
		$_SESSION['username'] = $_POST['username'];
		$_SESSION['name'] = $name;
		$_SESSION['priviledge'] = $account; 
		header('location: ../index.php');
	} else {
        $message = 'Incorrect password!';
        echo "<script type='text/javascript'>alert('$message');</script>";
        //header('location: ../logIn.php');
	}
} else {
	$message = "Incorrect user";
    echo "<script type='text/javascript'>alert('$message');</script>";
    //header('location: ../logIn.php');
}
$stmt->close();
?>