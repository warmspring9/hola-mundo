<?php
include "DBcon.php";
session_start();
$description = filter_input(INPUT_POST, 'description');
$name = filter_input(INPUT_POST, 'name');
$location = filter_input(INPUT_POST, 'location');
$public = filter_input(INPUT_POST, 'public');
$date = filter_input(INPUT_POST, 'date');

if($public){
    $privacy = 'public';
} else{
    $privacy = 'private';
}
$us = $_SESSION["username"];

    $con = con();
    if($con->query("insert into events (id_user,name, location, privacy, description, date, status) 
    values ('$us','$name','$location','$privacy','$description','$date', 'active')"){
        echo "success";
    }
    
    $conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT max(id) a from events";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        // output data of each row
            while($row = $result->fetch_assoc()) {
                $id = $row["a"];
            }
        }
        echo $id;
    header('location: ../addImg.php?id='.$id);
?>