<?php
include "DBcon.php";
$name = filter_input(INPUT_POST, 'name');
$con = con();
$con->query("INSERT INTO `user_types`(`name`) VALUES ('$name')");
    header('location: ../grupCRUD.php');
?>