<?php  echo file_get_contents("head.html"); ?>
<?php echo file_get_contents("header.php"); ?>
    <?php
    session_start();
    echo"<!-- Flat iconbox  -->";
    echo"<section class=\"flat-row pad-bottom90px\">";
    echo"<div class=\"container\">";
    echo"<div class=\"flat-divider d51px\"></div>";
        $count = 0;
        $conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $usr = $_SESSION["username"];
        $priv = $_SESSION["priviledge"];
        $sql = "SELECT i.url img, e.name title, e.id_user author, e.id id from events e 
        left join event_photos i on e.id=i.id_event where e.privacy = 'public' AND e.status!='dis' AND e.id_user!='$usr' OR $priv=1 group by e.name";
        $result = $conn->query($sql);
        if($result){
        // output data of each row
            echo "<div class=\"row\">";
            while($row = $result->fetch_assoc()) {
            
		    echo "<div class=\"col-md-4\">";
		    echo   " <div class=\"flat-iconbox style3\">";
            echo "       <div class=\"icon-image\">";
            if($row["img"]){
                echo "<img src=".$row["img"]." alt=\"img\">";
            } else{
                echo "<img src=\"https://www.okcballet.org/wp-content/uploads/2016/09/placeholder-image.png\" alt=\"img\" height=\"100\">";
            }
		    echo "       </div>";
				echo"<div class=\"content\">"; //poner en el href de abajo un .php que genere la info por su id
					echo "<h6 class=\"title\"><a href=\"work_detail.php?id=".$row["id"]."\">".$row["title"]."</a></h6>";            
					echo "<p>".$row["author"]."</p>"; 
				echo"</div>";
			echo"</div><!-- /.flat-iconbox -->";
            echo"</div><!-- /.col-md-4 -->";
            

            $count = $count+1;
            if($count% 3 == 0){
                echo "</div><!-- /.row -->";
                echo "<div class=\"flat-divider d51px\"></div>";
                echo "<div class=\"row\">";
            }
        }
        }else { echo "<a>You don't have events registered</a><br></br>"; 
            echo "<a href=\"createEvents.php\">Add an event</a>";
        }
        $conn->close();
        ?>
        </div><!-- /.container -->
    </section>

<?php echo file_get_contents("footer.html"); ?>