
<div class="boxed">     

<!-- Header -->            
<header id="header" class="header clearfix"> 
    <div class="header-wrap clearfix">
        <div id="logo" class="logo">
            <a href="index.php" rel="home">
                <img src="icon/android-icon-48x48.png" alt="image">
            </a>
        </div><!-- /.logo -->
        <div class="nav-wrap">
            <div class="btn-menu">
                <span></span>
            </div><!-- //mobile menu button -->
            <nav id="mainnav" class="mainnav">
                        <ul class="menu">
                            <li class="home">
                                <a href="index.php">Home</a>
                            </li>                           
                            <li><a href="#">Events</a>
                                <ul class="submenu">
                                    <li><a href="createEvents.php">Create Events</a></li>
                                    <li><a href="myEvents.php">My Events</a></li>
                                    <li><a href="explore.php">Explore</a></li>
                                    <li><a href="myinvites.php">Invites</a></li>
                                </ul><!-- /.submenu -->
                            </li>                      
                            <li><a href="user_info.php">Profile </a></li>
                            <li><a href="#">Administration </a>
                                <ul class="submenu">
                                    <li><a href="catCRUD.php">Categories</a></li>
                                    <li><a href="grupCRUD.php">Groups</a></li>
                                    <li><a href="usersAdmin.php">Users</a></li>
                                    <li><a href="reports.php">Reports</a></li>
                                    <li><a href="pieTest.php">Statistics</a></li>
                                </ul><!-- /.submenu -->
                            </li>
                            <li><a href="logout.php">Logout </a>
                            </li>
                        </ul><!-- /.menu -->
                    </nav><!-- /.mainnav -->  
                </div><!-- /.nav-wrap -->
                <div class="show-search">
                    <a href="#"><i class="fa fa-search"></i></a>   
                    <p class="cart">1</p>             
                </div><!-- /.show-search --> 
            </div><!-- /.header-inner --> 
        </header><!-- /.header -->
