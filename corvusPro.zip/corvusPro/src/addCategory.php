<?php  echo file_get_contents("head.html"); ?>
<?php echo file_get_contents("header.php");?>
<div class="update">
<?php
    include "dataAccess/DBcon.php";
    $con = con();
    $id = $_GET["id"];
    $sql = "SELECT name from events where id = $id";
    $result = $con->query($sql);
    if ($result) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
        echo "<h1>Add Categories to Event ".$row["name"]."</h1>";
        echo "<form method=\"post\" action=\"dataAccess/includeCat.php\" required>";
        echo "<input type=\"text\" name=\"id\" value=\"".$id."\" hidden>";
        echo "<label for=\"image\">Category</label>";
        echo "<input type=\"number\" name=\"category\" placeholder=\"id_category\" required>";
        }
    }
    echo "<input type=\"submit\" value=\"Submit\">";
    echo "<a href='work_detail.php?id=".$id."'><input type=\"button\" value=\"Finnish\" ></a>";
    echo "</form>";

    echo "<table border=\"1\" style=\"width:100%\">";
echo "<thead>";
echo "<tr>";
echo "<th>id</th>";
echo "<th>name</th>";
echo "</tr>";
echo "</thead>";
$conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT id, name FROM `category` except select id_category, c.name from categoryxevent ce join category c on ce.id_category = c.id where id_event = $id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo    "<tr>";
            echo    "<td>".$row["id"]."</td>";
            echo    "<td>".$row["name"]."</td>";
            echo    "</tr>";
        }
    }
    echo "</table>";
    echo "</div>";
?>

<?php echo file_get_contents("footer.html");?>