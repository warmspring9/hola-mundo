<?php  echo file_get_contents("head.html"); ?>
<?php 
echo file_get_contents("adminHeader.php");?>
<?php 
echo"<section class=\"flat-row pad-bottom90px\">";
echo"<div class=\"container\">";
echo"<div class=\"row\">";
echo"<div class=\"col-md-12\">";
echo"<div class=\"title-section\">";
echo "<div class=\"login\"><h1>Add Groups</h1><form method=\"post\" action=\"dataAccess/addGrup.php\">
<input type=\"text\" name=\"name\" placeholder=\"name\" required>
<input type=\"submit\" value=\"add\">
</form></div>";
echo "
<table border=\"1\" style=\"width:100%\">
<thead>
  <tr>
  <th>Group</th>
  <th>Users</th>
   </tr>
</thead>";
$conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT t.name name, count(ut.type_id) users, t.id id FROM usersxtypes ut right join user_types t on ut.type_id=t.id group by t.name";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo    "<tr>";
            echo    "<td>".$row["name"]."</td>";
            echo    "<td>".$row["users"]."</td>";
            echo    "</tr>";
        }
    }
    echo "</table>";
    echo"</div><!-- /.title-section -->";
    echo"</div><!-- /.col-md-12 -->";
    echo"</div><!-- /.row -->";
    echo"</div>";

echo"<div class=\"flat-divider d51px\"></div>";

    ?>
<br></br>
</section>

<?php echo file_get_contents("footer.html"); ?>