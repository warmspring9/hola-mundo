<?php  echo file_get_contents("head.html"); ?>
<?php 
echo file_get_contents("adminHeader.php");?>
<?php 
$ev = $_GET["id"];
echo $ev;
echo"<section class=\"flat-row pad-bottom90px\">";
echo"<div class=\"container\">";
echo"<div class=\"row\">";
echo"<div class=\"col-md-12\">";
echo"<div class=\"title-section\">";
echo "
<table border=\"1\" style=\"width:100%\">
<thead>
  <tr>
  <th>Event</th>
  <th>username</th>
  <th>email</th>
   </tr>
</thead>";
$conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT inv.id_event, evn.name, evn.date, evn.description ,evn.location
    FROM invites inv inner join events evn on inv.id_event = evn.id
    WHERE (inv.id_user = $us OR $us is NULL);";
    $result = $conn->query($sql);
    if ($result) {
        while($row = $result->fetch_assoc()) {
            echo    "<tr>";
            echo    "<td>".$row["name"]."</td>";
            echo    "<td>".$row["email"]."</td>";
            echo    "</tr>";
        }
    } else{
        echo "connection error";
    }
    echo "</table>";
    echo"</div><!-- /.title-section -->";
    echo"</div><!-- /.col-md-12 -->";
    echo"</div><!-- /.row -->";
    echo"</div>";

    
echo"<div class=\"flat-divider d51px\"></div>";

?>
<br></br>
</section>

<?php echo file_get_contents("footer.html"); ?>