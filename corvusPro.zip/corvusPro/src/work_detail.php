<?php  echo file_get_contents("head.html"); ?>
<?php echo file_get_contents("header.php"); ?>  
<?php            
        session_start();
        $us = $_SESSION["username"];
        $priv = $_SESSION["priviledge"];
        echo "<div class=\"page-title parallax parallax1\">";
        echo "<div class=\"container\">";
        echo "<div class=\"row\">";
        echo "<div class=\"col-md-12\">   ";                 
        echo "<div class=\"page-title-heading\">";
        echo "<img src=\"https://img.wallpapersafari.com/desktop/1920/1080/83/22/b1UswB.jpg\">";
        echo "</div><!-- /.page-title-captions --> ";
        echo "</div><!-- /.col-md-12 -->  ";
        echo "</div><!-- /.row -->  ";
        echo "</div><!-- /.container -->     ";                 
        echo "</div><!-- /.page-title --> ";

        echo "<section class=\"flat-row\">";
        echo "<div class=\"container\">";
        echo "<div class=\"row\">";
        echo "<div class=\"col-md-4\">";
        echo "<ul class=\"entry-portfolio-details\">";

                            $ev = $_GET["id"];
                            $conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");
                            // Check connection
                            if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                            }
                            $sql = "SELECT name, id_user, location, privacy, date from events ce where id = $ev";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    $name = $row['name'];
                                    $user = $row['id_user'];
                                    $date = $row['date'];
                                    $location = $row['location'];
                                    $privacy = $row['privacy'];
                                }
                                echo "<li><span>Title     </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$name."</li> ";
                                echo "<li><span>Author    </span>&nbsp;&nbsp;&nbsp;&nbsp;".$user."</li> ";
                                echo "<li><span>Date      </span>&nbsp;&nbsp;&nbsp;&nbsp;".$date."</li>";    
                                echo "<li><span>location  </span>&nbsp;&nbsp;".$location."</li>";
                                echo "<li><span>privacy   </span>&nbsp;&nbsp;&nbsp;".$privacy."</li>";
                            }
                            $sql = "SELECT c.name from categoryxevent ce
                            join category c on ce.id_category=c.id 
                            where ce.id_event = $ev";
                            $result = $conn->query($sql);
                            echo "<li><span>Categories</span>";
                            if(!$result){
                                echo "no categories";
                            } else{
                                while($row = $result->fetch_assoc()) {
                                    echo $row['name'];
                                }
                            }
                            echo "</li>";
                               
                           /*<!--- <li class="share"><span>share&nbsp;&nbsp;</span>
                                <ul class="flat-socials">
                                    <li class="facebook">
                                        <a href="#"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li class="twitter">
                                        <a href="#"><i class="fa fa-twitter"></i></a>
                                    </li>                                
                                    <li class="linkedin">
                                        <a href="#"><i class="fa fa-linkedin"></i></a>
                                    </li>
                                    <li class="instagram">
                                        <a href="#"><i class="fa fa-instagram"></i></a>
                                    </li>
                                </ul>
                            </li>  --> */                        
                        echo"</ul>";
                    echo"</div><!-- /.col-md-4 -->";

                    echo"<div class=\"col-md-8\">";
                        echo"<div class=\"content-portfolio-detail\">";
                        $sql = "SELECT description from events where id = $ev";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    $description = $row["description"];
                                }
                                echo    "<p>".$description." </p>";
                            }
                        echo    "</div>";
                        echo    "</div><!-- /.col-md-8 -->";
                echo "</div><!-- /.row -->";
               
                echo "<div class=\"flat-divider d51px\"></div>";
                ?>
                <section class="flat-row background-color-ecf1f5">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="flat-iconbox style1 v1">
                        <div class="icon-image">
                            <a href="dataAccess/vote.php?id=<?php echo $_GET["id"] ?>&vote=Asistire"><span class="icon-Alarm-Clock"></span></a>
                        </div>
                        <div class="flat-countdown">
                            <?php
                                $ev = $_GET["id"];
                                include "dataAccess/DBcon.php";
                                $id = $_GET["id"];
                                $con = con();
                                $result = $con->query("select count(id_user) tot from replies where id_event='$id' and type='Asistire'");
                                if($result){
                                    while($row = $result->fetch_assoc()) {
                                        echo "<div class=\"numb-count\" data-to=\"\" data-speed=\"20\" data-waypoint-active=\"yes\">".$row["tot"]."</div>";
                                    }
                                }
                            ?>
                            
                        </div>
                        <div class="icon-img">
                            <img src="images/icon/line1.png" alt="image">
                        </div>
                        <div class="content">
                            <p>Asistire</p>
                        </div>
                    </div><!-- /.flat-iconbox center style1 -->
                </div><!-- /.col-md-3 -->

                <div class="col-md-3">
                    <div class="flat-iconbox style1 v2">
                        <div class="icon-image">
                        <a href="dataAccess/vote.php?id=<?php echo $_GET["id"] ?>&vote=Estoy_Interesado"><span class="icon-Alien-2"></span></a>
                        </div>
                        <div class="flat-countdown">
                        <?php
                                $ev = $_GET["id"];
                                $id = $_GET["id"];
                                $result = $con->query("select count(id_user) tot from replies where id_event='$id' and type='Estoy_Interesado'");
                                if($result){
                                    while($row = $result->fetch_assoc()) {
                                        echo "<div class=\"numb-count\" data-to=\"\" data-speed=\"20\" data-waypoint-active=\"yes\">".$row["tot"]."</div>";
                                    }
                                }
                            ?>                        </div>
                        <div class="icon-img">
                            <img src="images/icon/line1.png" alt="image">
                        </div>
                        <div class="content">
                            <p>Estoy interesado</p>
                        </div>
                    </div><!-- /.flat-iconbox center style1 -->
                </div><!-- /.col-md-3 -->

                <div class="col-md-3">
                    <div class="flat-iconbox style1 v3">
                        <div class="icon-image">
                        <a href="dataAccess/vote.php?id=<?php echo $_GET["id"] ?>&vote=Tal_vez"><span class="icon-Archery-2"></span></a>
                        </div>
                        <div class="flat-countdown">
                        <?php
                                $ev = $_GET["id"];
                                $id = $_GET["id"];
                                $result = $con->query("select count(id_user) tot from replies where id_event='$id' and type='Tal_vez'");
                                if($result){
                                    while($row = $result->fetch_assoc()) {
                                        echo "<div class=\"numb-count\" data-to=\"\" data-speed=\"20\" data-waypoint-active=\"yes\">".$row["tot"]."</div>";
                                    }
                                }
                            ?>                        </div>
                        <div class="icon-img">
                            <img src="images/icon/line1.png" alt="image">
                        </div>
                        <div class="content">
                            <p>Tal vez asista</p>
                        </div>
                    </div><!-- /.flat-iconbox center style1 -->
                </div><!-- /.col-md-3 -->

                <div class="col-md-3">
                    <div class="flat-iconbox style1 v4">
                        <div class="icon-image">
                        <a href="dataAccess/vote.php?id=<?php echo $_GET["id"] ?>&vote=No_Asitire"><span class="icon-Atom"></span></a>
                        </div>
                        <div class="flat-countdown">
                        <?php
                                $ev = $_GET["id"];
                                $id = $_GET["id"];
                                $result = $con->query("select count(id_user) tot from replies where id_event='$id' and type='No_Asistire'");
                                if($result){
                                    while($row = $result->fetch_assoc()) {
                                        echo "<div class=\"numb-count\" data-to=\"\" data-speed=\"20\" data-waypoint-active=\"yes\">".$row["tot"]."</div>";
                                    }
                                }
                            ?>                        </div>
                        <div class="icon-img">
                            <img src="images/icon/line1.png" alt="image">
                        </div>
                        <div class="content">
                            <p>No ire</p>
                        </div>
                    </div><!-- /.flat-iconbox center style1 -->
                </div><!-- /.col-md-3 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>
                <div class="row">
                    <div class="col-md-12">
                        <div class="flat-carousel portfolio-detail" data-item="3" data-nav="false" data-dots="true" data-auto="true" data-margin="30">
                            <?php
                            $ev = $_GET["id"];
                            $conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");
                            // Check connection
                            if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                            }
                            $sql = "SELECT url from event_photos where id_event = $ev";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                echo    "<div class=\"single-img\" >";
                                echo    "<img src=".$row["url"]." alt=\"image\">";
                                echo    "</div>";
                                }
                            }
                           
                            
                           
                            
                        echo "</div><!-- /.flat-carousel -->";
                        echo "</div><!-- /.col-md-12 -->";
                        echo "</div><!-- /.row -->";
                            
                        echo "<div class=\"row\">";
                        echo "<div class=\"col-md-12\">";
                        if($user == $us || $priv == 1) {
                            echo "<div class=\"update\">";
                        echo "<h1>Event update</h1>";
                        echo "<form method=\"post\" action=\"dataAccess/updEv.php\" required>";
                        echo "<input type=\"text\" name=\"id\" value=\"$ev\" hidden>";
                        echo "<input type=\"text\" name=\"name\" value=\"".$name."\" required>";
                        echo "<input id=\"textArea\" type=\"text\" name=\"description\" value=\"".$description."\" required>";
                        echo "<input type=\"text\" name=\"location\" value=\"".$location."\" required>";
                        if($privacy=='public'){
                            echo "<input type=\"checkbox\" name=\"public\" checked >";
                        } else {
                            echo "<input type=\"checkbox\" name=\"public\"  >";
                        }
                        echo "<label>public</label>";
                        echo "<input type=\"date\" name=\"date\" value=\"".$date."\" required>";
                        echo "<input type=\"submit\" value=\"Submit\">";
                        echo "<a href='invEvent.php?id=$ev'><input type=\"button\" value=\"Invite\" ></a>";
                        echo "<a href='dataAccess/delEvent.php?id=$ev'><input type=\"button\" value=\"Delete\" ></a>";
                        echo "</form>";
                        echo "</div>";
                        }  
                        
                    ?>
                    </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section>
        <?php 
echo"<section class=\"flat-row pad-bottom90px\">";
echo"<div class=\"container\">";
echo"<div class=\"row\">";
echo"<div class=\"col-md-12\">";
echo"<div class=\"title-section\">";
echo "
<table border=\"1\" style=\"width:100%\">
<thead>
  <tr>
  <th>Author</th>
  <th>Comment</th>
   </tr>
</thead>";
$ev = $_GET["id"];
$conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT u.name author, c.content comment from comments c join users u on c.id_user=u.username where c.id_event='$ev'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo    "<tr>";
            echo    "<td>".$row["author"]."</td>";
            echo    "<td>".$row["comment"]."</td>";
            echo    "</tr>";
        }
    }
    echo "</table>";
    echo "<div class=\"login\"><h1>Add Comment</h1><form method=\"post\" action=\"dataAccess/addComent.php\">
    <input type=\"text\" name=\"id\" value=\"".$ev."\" hidden>
<input type=\"text\" id=\"textArea\" name=\"comment\" placeholder=\"comment\" required>
<input type=\"submit\" value=\"submit\">
</form></div>";
    echo"</div><!-- /.title-section -->";
    echo"</div><!-- /.col-md-12 -->";
    echo"</div><!-- /.row -->";
    echo"</div>";

echo"<div class=\"flat-divider d51px\"></div>";

    ?>
<br></br>
</section>

<?php echo file_get_contents("footer.html"); ?>