<?php
session_start();
$priv = $_SESSION["priviledge"];
if($priv == 1){
    echo "hello admin";
} else{
    echo "you shall not pass";
}

?>