<?php
include "dataAccess/DBcon.php";
session_start();
session_destroy();
// Redirect to the login page:
$con = con();
$con->query("commit");
header('Location: logIn.php');
?>