<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"><![endif]-->
<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>Corvus html template</title>

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Bootstrap  -->
    <link rel="stylesheet" type="text/css" href="stylesheets/bootstrap.css" >

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/style.css">

    <!-- Responsive -->
    <link rel="stylesheet" type="text/css" href="stylesheets/responsive.css">

    <!-- Colors -->
    <link rel="stylesheet" type="text/css" href="stylesheets/colors/color1.css" id="colors">
    
    <!-- Animation Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/animate.css">

    <!-- Favicon and touch icons  -->
    <link href="icon/apple-touch-icon-48-precomposed.png" rel="apple-touch-icon-precomposed" sizes="48x48">
    <link href="icon/apple-touch-icon-32-precomposed.png" rel="apple-touch-icon-precomposed">
    <link href="icon/favicon.png" rel="shortcut icon">

    <!--[if lt IE 9]>
        <script src="javascript/html5shiv.js"></script>
        <script src="javascript/respond.min.js"></script>
    <![endif]-->
</head>                                 
<body class="header-sticky">

    <section class="loading-overlay">
        <div class="Loading-Page">
            <h2 class="loader">Loading...</h2>
        </div>
    </section> 
    
    <!-- Boxed -->
    <div class="boxed">     

        <!-- Header -->            
        <header id="header" class="header clearfix"> 
            <div class="header-wrap clearfix">
                <div id="logo" class="logo">
                    <a href="index.html" rel="home">
                        <img src="images/logo.png" alt="image">
                    </a>
                </div><!-- /.logo -->
                <div class="nav-wrap">
                    <div class="btn-menu">
                        <span></span>
                    </div><!-- //mobile menu button -->
                    <nav id="mainnav" class="mainnav">
                        <ul class="menu"> 
                            <li class="home">
                                <a href="index.html">Home</a>
                                <ul class="submenu"> 
                                    <li><a href="index.html">Home version 1</a>
                                    </li>
                                    <li><a href="index_2.html">Home version 2</a></li>
                                    <li><a href="index_animated.html">Home Animated</a></li>
                                </ul><!-- /.submenu -->
                            </li>
                            <li><a href="./#about">Pages</a>
                                <ul class="submenu"> 
                                    <li class="sub-parent"><a href="#">About Us</a>
                                        <ul class="submenu"> 
                                            <li><a href="about_me.html">About Me 01</a></li>
                                            <li><a href="about_me_2.html">About Me 02</a></li>
                                            <li><a href="about_us_1.html">About Us 01</a></li>
                                            <li><a href="about_us_2.html">About Us 02</a></li>
                                        </ul><!-- /.submenu -->
                                    </li>
                                    <li class="sub-parent"><a href="#">Services</a>
                                        <ul class="submenu"> 
                                            <li><a href="services_1.html">Services 01</a></li>
                                            <li><a href="services_2.html">Services 02</a></li>
                                            <li><a href="services_detail.html">Services Detail</a></li>
                                        </ul><!-- /.submenu -->
                                    </li> 
                                    <li class="sub-parent"><a href="">Contac Us</a>
                                        <ul class="submenu"> 
                                            <li><a href="contact_us_1.html">Contact 01</a></li>
                                            <li><a href="contact_us_2.html">Contact 02</a></li>                                            
                                        </ul><!-- /.submenu -->               
                                    </li>                                   
                                </ul><!-- /.submenu -->
                            </li>
                            <li><a href="#">Features</a>
                                <ul class="submenu">
                                    <li><a href="page_title_v1.html">Page title</a></li>
                                </ul><!-- /.submenu -->
                            </li>
                            <li><a href="#"> Elements</a>
                                <ul class="submenu">
                                    <li><a href="meet_the_team.html">Meet the team</a></li>
                                    <li><a href="heading_style.html">Heading style</a></li>
                                </ul>                            
                            </li>                            
                            <li><a href="#">Work</a>
                                <ul class="submenu">
                                    <li><a href="work.html">Work - Grid 3 Columns</a></li>
                                    <li><a href="work_fullwidth.html">Work - Grid 4 Columns</a></li>
                                    <li><a href="work_masory.html">Work Masory</a></li>
                                    <li><a href="work_detail.html">Work Detail</a></li>
                                    <li><a href="work_detail_1.html">Work Detail Style 01</a></li>
                                    <li><a href="work_detail_2.html">Work Detail Style 02</a></li>
                                </ul><!-- /.submenu -->
                            </li>                            
                            <li><a href="blog.html">Blog </a>
                                <ul class="submenu right-sub-menu"> 
                                    <li><a href="blog_masory.html">Blog Masonry</a>
                                    </li>
                                    <li><a href="blog_v2.html">Blog_v2.html</a></li>
                                    <li><a href="blog_v3.html">Blog_v3.html</a></li>
                                    <li><a href="blog_v4.html">Blog_v4.html</a></li>
                                    <li><a href="blog_single.html">Blog Single</a></li>
                                </ul><!-- /.submenu -->
                            </li>
                            <li class="sub-parent"><a href="#">Services</a>
                                <ul class="submenu right-sub-menu"> 
                                    <li><a href="services_1.html">Services 01</a></li>
                                    <li><a href="services_2.html">Services 02</a></li>
                                    <li><a href="services_detail.html">Services Detail</a></li>
                                </ul><!-- /.submenu -->
                            </li> 
                        </ul><!-- /.menu -->
                    </nav><!-- /.mainnav -->  
                </div><!-- /.nav-wrap -->
                <div class="show-search">
                    <a href="#"><i class="fa fa-search"></i></a>   
                    <p class="cart">1</p>             
                </div><!-- /.show-search --> 
            </div><!-- /.header-inner --> 
        </header><!-- /.header -->
                
        <!-- Page title -->
        <div class="page-title parallax parallax1">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">                    
                        <div class="page-title-heading">
                            <h3 class="title">Welcome to our blog</h3>
                        </div><!-- /.page-title-captions --> 
                    </div><!-- /.col-md-12 -->  
                </div><!-- /.row -->  
            </div><!-- /.container -->                      
        </div><!-- /.page-title --> 

        <!-- Blog single -->
        <section class="main-content blog-post blog-single style3">
            <div class="container">
                <div class="row">
                    <div class="col-md-9">
                        <div class="post-wrap">
                            
                            <article class="post">
                                <div class="feature-post">
                                    <img src="images/blog/bs.jpg" alt="image">
                                </div><!-- /.feature-post -->

                                <div class="main-post">
                                    <h4 class="title-post">
                                        Designing Healthcare Apps
                                    </h4>
                                    <div class="meta-post">                              
                                        <span class="author"><a href="#">Charlie Walter</a></span>
                                        <span class="date"><a href="#">November 18th, 2016</a></span>
                                        <span class="tag"><a href="#">Graphic, Website</a></span>
                                        <span class="comment"><a href="#">3 comment’s</a></span>
                                    </div><!-- /.entry-meta -->

                                    <div class="entry-post">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In rutrum odio urna, vitae ultrices mi malesuada ut. Praesent lacus erat, ultricies ut risus nec, pellentesque interdum purus. In mi justo, consectetur tincidunt sapien eget, venenatis volutpat risus. Maecenas eget pretium eros. Integer tincidunt aliquet ligula in vulputate. Ut ut justo facilisis, vulputate augue vel, vestibulum tortor. Nullam varius lacus non porttitor sodales. Vivamus ultricies est vitae pharetra convallis. Sed suscipit, nisi sit amet tempus mollis, mauris ante tempor risus, eu imperdiet ante felis vitae risus. Cras massa mi, condimentum at dignissim id, auctor ut arcu. Phasellus vitae pellentesque quam, sed blandit eros. Quisque malesuada arcu vel diam cursus posuere. Pellentesque faucibus risus libero.</p>
                                        <p>Curabitur eu sem id velit pulvinar ultricies a in felis. Nulla in velit scelerisque, rutrum mi at, sollicitudin enim. Maecenas sollicitudin odio at laoreet congue. Morbi at sem eu leo posuere congue. Praesent vulputate semper erat at pellentesque. Pellentesque molestie laoreet lacus, eget cursus erat pellentesque euismod. Nullam dictum, massa in fermentum venenatis, odio sem commodo eros, in ullamcorper nisi felis vel nibh. Nam id neque a odio scelerisque pretium sit amet quis leo. Aliquam imperdiet dignissim lacus ut eleifend. Sed venenatis ante sed neque commodo condimentum.</p>

                                        <blockquote>
                                            <div class="blockqoute-text">
                                                <p>Curabitur fermentum leo tellus, ut volutpat sem laoreet ac. Donec ut dui consectetur, eleifend nisi at, euismod nisl. Cras eu leo nunc. Sed cursus luctus sapien vel tincidunt. Pellentesque et augue at augue faucibus vestibulum ut vel eros. Vivamus mollis, ligula non venenatis tempor, justo orci posuere tellus, vel hendrerit enim dolor consequat justo. Morbi pellentesque mi eget dolor tempus cursus.</p>
                                            </div>
                                        </blockquote>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In rutrum odio urna, vitae ultrices mi malesuada ut. Praesent lacus erat, ultricies ut risus nec, pellentesque interdum purus. In mi justo, consectetur tincidunt sapien eget, venenatis volutpat risus. Maecenas eget pretium eros. Integer tincidunt aliquet ligula in vulputate. Ut ut justo facilisis, vulputate augue vel, vestibulum tortor. Nullam varius lacus non porttitor sodales. Vivamus ultricies est vitae pharetra convallis. Sed suscipit, nisi sit amet tempus mollis, mauris ante tempor risus, eu imperdiet ante felis vitae risus. Cras massa mi, condimentum at dignissim id, auctor ut arcu. Phasellus vitae pellentesque quam, sed blandit eros. Quisque malesuada arcu vel diam cursus posuere. Pellentesque faucibus risus libero.</p>

                                        <img src="images/blog/bs0.jpg" alt="image">
                                        <h5 class="entry-post-title">Heading Caption</h5>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In rutrum odio urna, vitae ultrices mi malesuada ut. Praesent lacus erat, ultricies ut risus nec, pellentesque interdum purus. In mi justo, consectetur tincidunt sapien eget, venenatis volutpat risus. Maecenas eget pretium eros. Integer tincidunt aliquet ligula in vulputate. Ut ut justo facilisis, vulputate augue vel, vestibulum tortor. Nullam varius lacus non porttitor sodales. Vivamus ultricies est vitae pharetra convallis. Sed suscipit, nisi sit amet tempus mollis, mauris ante tempor risus, eu imperdiet ante felis vitae risus. Cras massa mi, condimentum at dignissim id, auctor ut arcu. Phasellus vitae pellentesque quam, sed blandit eros. Quisque malesuada arcu vel diam cursus posuere.<br>Pellentesque faucibus risus libero.</p>
                                    </div><!-- /.entry-content -->
                                    <div class="wrap-share">
                                        <ul class="category-post">
                                            <li>Posted in</li> 
                                            <li><a href="#">Design,</a></li> 
                                            <li><a href="#">Inspiration,</a></li>
                                            <li><a href="#">Feature.</a></li>                 
                                        </ul><!-- /.post-in -->

                                        <div class="share-post">                                   
                                            <ul class="flat-socials">
                                                <li class="facebook">
                                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                                </li>
                                                <li class="twitter">
                                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                                </li>
                                                <li class="instagram">
                                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                                </li>
                                                <li class="linkedin">
                                                    <a href="#"><i class="fa fa-linkedin"></i></a>
                                                </li>
                                            </ul>
                                        </div><!-- /.share-post -->      
                                    </div><!-- /.wrap-share --> 
                                </div><!-- /.main-post -->
                            </article> 

                            <div class="author-post">
                                <h6 class="title author-title">About the Author</h6>
                                <article class="author">
                                    <div class="author-avatar">
                                        <img src="images/blog/author.jpg" alt="image">
                                    </div>                  
                                    <div class="author-detail">
                                        <div class="author-meta">
                                            <h6>Steven Bradley</h6>
                                        </div>
                                        <p class="author-body">Vivamus imperdiet ex sed lobortis luctus. Aenean posuere nulla in turpis porttitor laoreet. Quisque finibus aliquet purus. Ut et mi eu ante interdum .</p>
                                    </div>
                                </article><!-- /.comment -->
                            </div><!-- /.author-post -->

                            <div class="comment-post">
                                <div class="comment-list-wrap">
                                    <h6 class="title comment-title">3 Comments</h6>
                                    <ul class="comment-list">
                                        <li>
                                            <article class="comment">
                                                <div class="comment-avatar">
                                                    <img src="images/blog/author2.png" alt="image">
                                                </div>                  
                                                <div class="comment-detail">
                                                    <div class="comment-meta">
                                                        <span class="comment-author"><a href="#">Steven Bradley</a></span> 
                                                        <span class="comment-date"><a href="">5 months ago</a></span> 
                                                        <a href="#" class="comment-reply">Reply</a>
                                                    </div>
                                                    <p class="comment-body">Vivamus imperdiet ex sed lobortis luctus. Aenean posuere nulla in turpis porttitor laoreet. Quisque finibus aliquet purus.</p>
                                                </div><!-- /.comment-detail -->
                                            </article><!-- /.comment -->
                                            <ul class="children">
                                                <li>
                                                    <article class="comment">
                                                        <div class="comment-avatar">
                                                            <img src="images/blog/author3.png" alt="image">
                                                        </div>                  
                                                        <div class="comment-detail">
                                                            <div class="comment-meta">
                                                                <span class="comment-author"><a href="#">Steven Bradley</a></span> 
                                                                <span class="comment-date"><a href="">5 months ago</a></span> 
                                                                <a href="#" class="comment-reply">Reply</a>
                                                            </div>
                                                            <p class="comment-body">Maecenas euismod faucibus dolor a finibus.</p>
                                                        </div><!-- /.comment-detail -->
                                                    </article><!-- /.comment -->
                                                </li>
                                            </ul><!-- /.children -->
                                        </li>

                                        <li>
                                            <article class="comment">
                                                <div class="comment-avatar">
                                                    <img src="images/blog/author4.png" alt="image">
                                                </div>                  
                                                <div class="comment-detail">
                                                    <div class="comment-meta">
                                                        <span class="comment-author"><a href="#">Steven Bradley</a></span> 
                                                        <span class="comment-date"><a href="">5 months ago</a></span> 
                                                        <a href="#" class="comment-reply">Reply</a>
                                                    </div>
                                                    <p class="comment-body">Vivamus imperdiet ex sed lobortis luctus. Aenean posuere nulla in turpis porttitor laoreet. Quisque finibus aliquet purus. Ut et mi eu ante interdum dignissim pellentesque a mi.</p>
                                                </div><!-- /.comment-detail -->
                                            </article><!-- /.comment -->
                                        </li>
                                    </ul><!-- /.comment-list -->
                                </div><!-- /.comment-list-wrap -->

                                <div id="respond" class="comment-respond">
                                    <h4 class="title comment-title">Leave a reply</h4>
                                    <form action="#" method="post" id="commentform" class="comment-form" novalidate="">                                                                   
                                        <fieldset class="name-container">
                                            <label>Name</label>
                                            <input type="text" id="author" class="tb-my-input" name="author" tabindex="1" value="" size="32" aria-required="true">
                                        </fieldset>

                                        
                                        <fieldset class="email-container">
                                            <label>Email</label>
                                            <input type="text" id="email" class="tb-my-input" name="email" tabindex="2" value="" size="32" aria-required="true">
                                        </fieldset> 

                                        
                                        <fieldset class="message">
                                            <label>Messager</label>  
                                            <textarea id="comment-message" name="comment" rows="8" tabindex="4"></textarea>
                                        </fieldset>
                                            <p class="form-submit">
                                            <input name="submit" type="submit" id="comment-reply" class="submit" value="send"> <input type="hidden" name="comment_post_ID" value="27" id="comment_post_ID">
                                            <input type="hidden" name="comment_parent" id="comment_parent" value="0">
                                            </p>                
                                    </form>
                                    <div class="next-prev-post">
                                        <a href="#" class="prev">Prev post</a>
                                        <a href="#" class="next">Next post</a>
                                    </div>
                                </div><!-- /#respond -->
                            </div><!-- /.comment-post -->   

                        </div><!-- /.post-wrap -->

                    </div><!-- /.col-md-9 -->

                    <div class="col-md-3">
                        <div class="sidebar">
                            <div class="widget widget-categories">
                                <h6 class="widget-title">Categories</h6>
                                <ul>
                                    <li><a href="#">Photoshop<span>(5)</span></a></li>
                                    <li><a href="#">Photography<span>(5)</span></a></li>
                                    <li><a href="#">Design<span>(5)</span></a></li>
                                    <li><a href="#">Development<span>(5)</span></a></li>   
                                    <li><a href="#">Illustrator<span>(5)</span></a></li>                                
                                </ul>
                            </div><!-- /.widget .widget-categories -->
     
                            <div class="widget widget-recent-post">
                                <h6 class="widget-title">Recent Posts</h6>
                                <ul>
                                    <li><a href="#">Smarter Grids With Sass And ...</a></li>
                                    <li><a href="#">Quantity Ordering With CSS</a></li>
                                    <li><a href="#">Gallery Post</a></li>
                                    <li><a href="#">Video Post</a></li>
                                    <li><a href="#">Image Post</a></li>
                                </ul>
                            </div><!-- /.widget .widget-recent-post -->

                            <div class="widget widget-tags">
                                <h6 class="widget-title">Tag</h6>
                                <div class="tag-list">
                                    <a href="#">Design</a>
                                    <a href="#">Branding</a>
                                    <a href="#">Concept</a>
                                    <a href="#">Website</a>
                                    <a href="#">Photography</a>     
                                </div>
                            </div><!-- /.widget .widget-tags -->

                            <div class="widget widget-instagram">
                                <h6 class="widget-title">Instagram </h6>
                                <div class="instagram-thumb clearfix">
                                    <div class="thumb">
                                        <a href="#"><img class="img" src="images/blog/flickr1.png" alt="image"></a>
                                    </div>
                                    <div class="thumb">
                                        <a href="#"><img class="img" src="images/blog/flickr2.png" alt="image"></a>
                                    </div>
                                    <div class="thumb">
                                        <a href="#"><img class="img" src="images/blog/flickr3.png" alt="image"></a>
                                    </div>
                                    <div class="thumb">
                                        <a href="#"><img class="img" src="images/blog/flickr4.png" alt="image"></a>
                                    </div>
                                    <div class="thumb">
                                        <a href="#"><img class="img" src="images/blog/flickr5.png" alt="image"></a>
                                    </div>
                                    <div class="thumb">
                                        <a href="#"><img class="img" src="images/blog/flickr6.png" alt="image"></a>
                                    </div>
                                    <div class="thumb">
                                        <a href="#"><img class="img" src="images/blog/flickr7.png" alt="image"></a>
                                    </div>
                                    <div class="thumb">
                                        <a href="#"><img class="img" src="images/blog/flickr8.png" alt="image"></a>
                                    </div>
                                    <div class="thumb">
                                        <a href="#"><img class="img" src="images/blog/flickr9.png" alt="image"></a>
                                    </div>
                                </div><!-- /.instagram-thumb -->
                            </div><!-- /.widget .widget-instagram -->

                            <div class="widget widget-recent-post style1">
                                <h6 class="widget-title">Recent posts</h6>
                                <ul class="post-news clearfix">
                                    <li>
                                        <div class="thumb">
                                            <a href="#"><img src="images/blog/thumb1.png" alt="image"></a>
                                        </div>
                                        <div class="text">                                        
                                            <h4><a href="#">Melancholy Middletons Yet Understood Decisively</a></h4>
                                            <p>December 9th, 2015</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="thumb">
                                           <a href="#"><img src="images/blog/thumb2.png" alt="image"></a>
                                        </div>
                                        <div class="text">
                                            <h4><a href="#">Melancholy Middletons Yet Understood Decisively</a></h4>
                                            <p>December 9th, 2015</p> 
                                        </div>
                                    </li>
                                    <li>
                                        <div class="thumb">
                                           <a href="#"><img src="images/blog/thumb3.png" alt="image"></a>
                                        </div>
                                        <div class="text">                                        
                                            <h4><a href="#">Melancholy Middletons Yet Understood Decisively</a></h4>
                                            <p>December 9th, 2015</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="thumb">
                                           <a href="#"><img src="images/blog/thumb4.png" alt="image"></a>
                                        </div>
                                        <div class="text">                                        
                                            <h4><a href="#">Melancholy Middletons Yet Understood Decisively</a></h4>
                                            <p>December 9th, 2015</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="thumb">
                                           <a href="#"><img src="images/blog/thumb5.png" alt="image"></a>
                                        </div>
                                        <div class="text">                                        
                                            <h4><a href="#">Melancholy Middletons Yet Understood Decisively</a></h4>
                                            <p>December 9th, 2015</p>
                                        </div>
                                    </li>
                                </ul><!-- /.post-news -->
                            </div><!-- /.widget .widget-recent-post style1 -->

                            <div class="widget widget-featured-post">
                                <h6 class="widget-title">Featured posts</h6>
                                <div class="widg-featured-post" data-item="1" data-nav="false" data-dots="true" data-auto="true">
                                    <div class="item">
                                        <a href="#"><img src="images/blog/wdslide.png" alt="images"></a>
                                        <div class="text">                                        
                                            <h6><a href="#">Melancholy Middletons Yet Understood Decisively</a></h6>
                                            <p>December 9th, 2016</p>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <a href="#"><img src="images/blog/wdslide.png" alt="images"></a>
                                        <div class="text">                                        
                                            <h6><a href="#">Melancholy Middletons Yet Understood Decisively</a></h6>
                                            <p>December 9th, 2016</p>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <a href="#"><img src="images/blog/wdslide.png" alt="images"></a>
                                        <div class="text">                                        
                                            <h6><a href="#">Melancholy Middletons Yet Understood Decisively</a></h6>
                                            <p>December 9th, 2016</p>
                                        </div>
                                    </div>                              
                                </div><!-- /.flat-client --> 
                            </div><!-- /.widget-featured-post -->

                            <div class="widget widget-tweets">
                                <h6 class="widget-title">Twitter recents</h6>
                                <div class="list-tiwtter" data-number="2" data-username="envato" data-modpath="twitter/index.php"><p class="loading">Loading Tweets...</p></div>                            
                            </div><!-- /.widget .widget-twitter-recent -->

                            <div class="widget widget-subscribe">
                                <h6 class="title">Subscribe</h6>
                                <p>Subscribe to get the latest</p>
                                <input type="text" placeholder="Enter your email address">
                                <div class="flat-button bg-themes" data-text="sign up"><a href="#">sign up</a></div>
                            </div><!-- /.widget .widget-sibscribe -->
                            
                        </div><!-- /.sidebar -->
                    </div><!-- /.col-md-3 -->

                </div><!-- /.row -->
            </div><!-- /.container -->   
        </section>

        <!-- Footer -->
        <footer class="footer">
            <div class="footer-widgets">
                <div class="container">
                    <div class="row"> 
                        <div class="col-md-3">  
                            <div class="widget widget-text">
                                <h6 class="widget-title">contact us</h6>
                                <div class="textwidget">                                
                                    <p><span>Phone : </span>61 3 8376 6284</p>
                                    <p><span>Address : </span>121 King Street, Melbourne</p>
                                    <p><span>Email : </span>Alitstudios@gmail.com</p>
                                </div><!-- /.textwidget -->
                            </div><!-- /.widget -->      
                        </div><!-- /.col-md-3 --> 

                         <div class="col-md-2">  
                            <div class="widget widget-services">
                                <h6 class="widget-title">services</h6>
                                <ul>
                                    <li><a href="#">Domain names</a></li>
                                    <li><a href="#">Web hosting</a></li>
                                    <li><a href="#">Wordpress Hosting</a></li>
                                    <li><a href="#">API</a></li>   
                                </ul>
                            </div>  
                        </div><!-- /.col-md-2 -->

                         <div class="col-md-2">  
                            <div class="widget widget-support">                            
                                <h6 class="widget-title">support</h6>
                                <ul>
                                    <li><a href="#">Getting Started</a></li>
                                    <li><a href="#">Meet the team</a></li>
                                    <li><a href="#">Datacenters</a></li>
                                    <li><a href="#">FAQ</a></li>   
                                </ul>
                            </div><!-- /.widget -->      
                        </div><!-- /.col-md-2 -->

                        <div class="col-md-2">
                            <div class="widget widget-company">
                                <h6 class="widget-title">company</h6>
                                <ul>
                                    <li><a href="#">About Us</a></li>
                                    <li><a href="#">Terms of Service</a></li>
                                    <li><a href="#">Client Area</a></li>
                                    <li><a href="#">Social Media</a></li>   
                                </ul>
                            </div><!-- /.widget -->
                        </div><!-- /.col-md-2 -->

                        <div class="col-md-3">
                            <div class="widget widget-mailchimb">
                                <h6 class="widget-title">stay in touch</h6>
                                <input type="email" name="EMAIL" placeholder="Enter your email" required="">
                                <button type="submit">Subscribe</button>
                            </div><!-- /.widget -->
                        </div><!-- /.col-md-2 -->

                    </div><!-- /.row -->    
                </div><!-- /.container -->
            </div><!-- /.footer-widgets -->

        </footer>

        <!-- Bottom -->
        <div class="bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright"> 
                            <p>© Copyright <a href="#">Alitstudio</a> 2015. All Rights Reserved.
                            </p>

                            <ul class="flat-socials">
                                <li class="facebook">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                </li>
                                <li class="twitter">
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                </li>
                                <li class="instagram">
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                </li>
                                <li class="linkedin">
                                    <a href="#"><i class="fa fa-linkedin"></i></a>
                                </li>
                            </ul>
                        </div>                   
                    </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div>

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div><!-- /.boxed -->   
    
    <!-- Javascript -->
    <script type="text/javascript" src="javascript/jquery.min.js"></script>
    <script type="text/javascript" src="javascript/bootstrap.min.js"></script> 
    <script type="text/javascript" src="javascript/jquery.easing.js"></script>
    <script type="text/javascript" src="javascript/owl.carousel.js"></script> 
    <script type="text/javascript" src="javascript/jquery.isotope.min.js"></script>
    <script type="text/javascript" src="javascript/imagesloaded.min.js"></script> 
    <script type="text/javascript" src="javascript/jquery-waypoints.js"></script> 
    <script type="text/javascript" src="javascript/jquery.tweet.min.js"></script>   
    <script type="text/javascript" src="javascript/jquery.cookie.js"></script>
    <script type="text/javascript" src="javascript/parallax.js"></script>   
    <script type="text/javascript" src="javascript/jquery.sticky.js"></script>    
    <script type="text/javascript" src="javascript/smoothscroll.js"></script>
    <script type="text/javascript" src="javascript/main.js"></script>
</body>
</html>