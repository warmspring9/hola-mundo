<?php  echo file_get_contents("head.html"); ?>
<?php 

$dataPoints = array();
$conn = mysqli_connect("localhost", "WPPro2", "Password9", "prodb");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT MONTHNAME(evn.date)  as month, count(evn.id) as li, (select count(1) from events)  as tot
    FROM events evn
    group by MONTH(evn.date);";
    $result = $conn->query($sql);
    if ($result) {
        while($row = $result->fetch_assoc()) {
            array_push($dataPoints,array("label"=>$row["month"],"y"=>$row["li"]/$row["tot"]));
        }
    }
echo file_get_contents("adminHeader.php");

echo"<section class=\"flat-row pad-bottom90px\">";
echo"<div class=\"container\">";
echo"<div class=\"row\">";
echo"<div class=\"col-md-12\">";
echo"<div class=\"title-section\">";
 

 
?>
<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Events"
	},
	subtitles: [{
		text: "per month"
	}],
	data: [{
		type: "pie",
		yValueFormatString: "#,##0.00\"%\"",
		indexLabel: "{label} ({y})",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
}
</script>

</div>
</div>

</div>

</div>

</section>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<div class="login">
<a href="pieTest3.php"><button>prev</button></a>
<a href="pieTest5.php"><button>next</button></a>
</div>
<?php echo file_get_contents("footer.html"); ?>